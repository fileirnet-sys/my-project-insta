export interface SafetyLimits {
  followsPerHour: number;
  unfollowsPerHour: number;
  likesPerHour: number;
  commentsPerHour: number;
  dmPerHour: number;
  followsPerDay: number;
  unfollowsPerDay: number;
  likesPerDay: number;
  commentsPerDay: number;
  dmPerDay: number;
}

export interface AccountStatus {
  isActive: boolean;
  isSuspended: boolean;
  suspensionReason: string;
  lastActivity: Date;
  warningLevel: 'safe' | 'warning' | 'danger' | 'critical';
  nextAllowedAction: Date;
  dailyActions: {
    follows: number;
    unfollows: number;
    likes: number;
    comments: number;
    dm: number;
  };
  hourlyActions: {
    follows: number;
    unfollows: number;
    likes: number;
    comments: number;
    dm: number;
  };
}

export const DEFAULT_SAFETY_LIMITS: SafetyLimits = {
  followsPerHour: 20,
  unfollowsPerHour: 25,
  likesPerHour: 60,
  commentsPerHour: 15,
  dmPerHour: 10,
  followsPerDay: 200,
  unfollowsPerDay: 250,
  likesPerDay: 800,
  commentsPerDay: 100,
  dmPerDay: 50,
};

export class InstagramSafetyMonitor {
  private accountStatus: AccountStatus;
  private safetyLimits: SafetyLimits;
  private suspensionCheckInterval: NodeJS.Timeout | null = null;
  private autoRestartTimeout: NodeJS.Timeout | null = null;

  constructor(limits: SafetyLimits = DEFAULT_SAFETY_LIMITS) {
    this.safetyLimits = limits;
    this.accountStatus = {
      isActive: false,
      isSuspended: false,
      suspensionReason: '',
      lastActivity: new Date(),
      warningLevel: 'safe',
      nextAllowedAction: new Date(),
      dailyActions: { follows: 0, unfollows: 0, likes: 0, comments: 0, dm: 0 },
      hourlyActions: { follows: 0, unfollows: 0, likes: 0, comments: 0, dm: 0 },
    };
  }

  startMonitoring(): void {
    this.suspensionCheckInterval = setInterval(() => {
      this.checkAccountStatus();
    }, 30000); // Check every 30 seconds

    // Reset hourly counters
    setInterval(() => {
      this.resetHourlyCounters();
    }, 3600000); // Every hour

    // Reset daily counters
    setInterval(() => {
      this.resetDailyCounters();
    }, 86400000); // Every 24 hours
  }

  stopMonitoring(): void {
    if (this.suspensionCheckInterval) {
      clearInterval(this.suspensionCheckInterval);
    }
    if (this.autoRestartTimeout) {
      clearTimeout(this.autoRestartTimeout);
    }
  }

  canPerformAction(actionType: keyof AccountStatus['hourlyActions']): boolean {
    if (this.accountStatus.isSuspended || this.accountStatus.warningLevel === 'critical') {
      return false;
    }

    const hourlyLimit = this.safetyLimits[`${actionType}PerHour` as keyof SafetyLimits] as number;
    const dailyLimit = this.safetyLimits[`${actionType}PerDay` as keyof SafetyLimits] as number;

    return (
      this.accountStatus.hourlyActions[actionType] < hourlyLimit &&
      this.accountStatus.dailyActions[actionType] < dailyLimit
    );
  }

  recordAction(actionType: keyof AccountStatus['hourlyActions']): void {
    this.accountStatus.hourlyActions[actionType]++;
    this.accountStatus.dailyActions[actionType]++;
    this.accountStatus.lastActivity = new Date();
    this.updateWarningLevel();
  }

  private updateWarningLevel(): void {
    const hourlyUsage = this.calculateUsagePercentage('hourly');
    const dailyUsage = this.calculateUsagePercentage('daily');
    const maxUsage = Math.max(hourlyUsage, dailyUsage);

    if (maxUsage >= 90) {
      this.accountStatus.warningLevel = 'critical';
    } else if (maxUsage >= 75) {
      this.accountStatus.warningLevel = 'danger';
    } else if (maxUsage >= 50) {
      this.accountStatus.warningLevel = 'warning';
    } else {
      this.accountStatus.warningLevel = 'safe';
    }
  }

  private calculateUsagePercentage(period: 'hourly' | 'daily'): number {
    const actions = period === 'hourly' ? this.accountStatus.hourlyActions : this.accountStatus.dailyActions;
    const limits = period === 'hourly' ? 
      {
        follows: this.safetyLimits.followsPerHour,
        unfollows: this.safetyLimits.unfollowsPerHour,
        likes: this.safetyLimits.likesPerHour,
        comments: this.safetyLimits.commentsPerHour,
        dm: this.safetyLimits.dmPerHour,
      } : 
      {
        follows: this.safetyLimits.followsPerDay,
        unfollows: this.safetyLimits.unfollowsPerDay,
        likes: this.safetyLimits.likesPerDay,
        comments: this.safetyLimits.commentsPerDay,
        dm: this.safetyLimits.dmPerDay,
      };

    const percentages = Object.keys(actions).map(key => {
      const actionKey = key as keyof typeof actions;
      return (actions[actionKey] / limits[actionKey]) * 100;
    });

    return Math.max(...percentages);
  }

  private checkAccountStatus(): void {
    // Simulate Instagram API check (in real implementation, this would check actual Instagram status)
    const suspicionIndicators = this.detectSuspicionIndicators();
    
    if (suspicionIndicators.length > 0) {
      this.handleSuspiciousActivity(suspicionIndicators);
    }
  }

  private detectSuspicionIndicators(): string[] {
    const indicators: string[] = [];
    
    // Check if we're hitting limits too frequently
    if (this.accountStatus.warningLevel === 'critical') {
      indicators.push('حد مجاز عملیات روزانه نزدیک است');
    }
    
    // Check for rapid consecutive actions
    const recentActions = this.accountStatus.hourlyActions;
    const totalRecentActions = Object.values(recentActions).reduce((sum, count) => sum + count, 0);
    
    if (totalRecentActions > 100) {
      indicators.push('تعداد عملیات در ساعت گذشته بیش از حد مجاز');
    }

    return indicators;
  }

  private handleSuspiciousActivity(indicators: string[]): void {
    console.warn('🚨 فعالیت مشکوک شناسایی شد:', indicators);
    
    this.accountStatus.isSuspended = true;
    this.accountStatus.suspensionReason = indicators.join(', ');
    this.accountStatus.isActive = false;
    
    // Schedule automatic restart after 2-4 hours
    const restartDelay = Math.random() * 2 * 60 * 60 * 1000 + 2 * 60 * 60 * 1000; // 2-4 hours
    this.scheduleAutoRestart(restartDelay);
  }

  private scheduleAutoRestart(delay: number): void {
    this.autoRestartTimeout = setTimeout(() => {
      this.attemptAutoRestart();
    }, delay);
  }

  private attemptAutoRestart(): void {
    console.log('🔄 تلاش برای راه‌اندازی مجدد خودکار...');
    
    // Reset counters and status
    this.resetHourlyCounters();
    this.accountStatus.isSuspended = false;
    this.accountStatus.suspensionReason = '';
    this.accountStatus.warningLevel = 'safe';
    this.accountStatus.isActive = true;
    this.accountStatus.nextAllowedAction = new Date();
    
    console.log('✅ سیستم با موفقیت راه‌اندازی مجدد شد');
  }

  private resetHourlyCounters(): void {
    this.accountStatus.hourlyActions = { follows: 0, unfollows: 0, likes: 0, comments: 0, dm: 0 };
  }

  private resetDailyCounters(): void {
    this.accountStatus.dailyActions = { follows: 0, unfollows: 0, likes: 0, comments: 0, dm: 0 };
  }

  getAccountStatus(): AccountStatus {
    return { ...this.accountStatus };
  }

  getSafetyLimits(): SafetyLimits {
    return { ...this.safetyLimits };
  }

  updateSafetyLimits(newLimits: Partial<SafetyLimits>): void {
    this.safetyLimits = { ...this.safetyLimits, ...newLimits };
  }
}