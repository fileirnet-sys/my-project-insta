import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Play, 
  Pause, 
  Settings, 
  Activity, 
  Shield, 
  AlertTriangle,
  CheckCircle,
  RotateCcw
} from 'lucide-react';
import { InstagramBotManager } from '@/lib/bot-services';

interface BotControlPanelProps {
  botManager: InstagramBotManager;
  onStatusChange: () => void;
}

export function BotControlPanel({ botManager, onStatusChange }: BotControlPanelProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [accountStatus, setAccountStatus] = useState(botManager.getAccountStatus());

  useEffect(() => {
    const interval = setInterval(() => {
      setIsRunning(botManager.getBotStatus());
      setAccountStatus(botManager.getAccountStatus());
    }, 1000);

    return () => clearInterval(interval);
  }, [botManager]);

  const handleStartStop = () => {
    if (isRunning) {
      botManager.stopBot();
    } else {
      botManager.startBot();
    }
    onStatusChange();
  };

  const getStatusColor = () => {
    if (accountStatus.isSuspended) return 'text-red-600';
    if (!isRunning) return 'text-gray-600';
    switch (accountStatus.warningLevel) {
      case 'safe': return 'text-green-600';
      case 'warning': return 'text-yellow-600';
      case 'danger': return 'text-orange-600';
      case 'critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = () => {
    if (accountStatus.isSuspended) return <AlertTriangle className="h-5 w-5 text-red-600" />;
    if (!isRunning) return <Pause className="h-5 w-5 text-gray-600" />;
    switch (accountStatus.warningLevel) {
      case 'safe': return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
      case 'danger': return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      case 'critical': return <AlertTriangle className="h-5 w-5 text-red-600" />;
      default: return <Activity className="h-5 w-5 text-gray-600" />;
    }
  };

  const getStatusText = () => {
    if (accountStatus.isSuspended) return 'متوقف شده (امنیتی)';
    if (!isRunning) return 'غیرفعال';
    switch (accountStatus.warningLevel) {
      case 'safe': return 'فعال و ایمن';
      case 'warning': return 'فعال (هشدار)';
      case 'danger': return 'فعال (خطر)';
      case 'critical': return 'فعال (بحرانی)';
      default: return 'فعال';
    }
  };

  return (
    <div className="space-y-6">
      {/* Main Control Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            کنترل ربات اینستاگرام
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              {getStatusIcon()}
              <div>
                <div className={`font-medium ${getStatusColor()}`}>
                  {getStatusText()}
                </div>
                <div className="text-sm text-gray-600">
                  آخرین فعالیت: {accountStatus.lastActivity.toLocaleString('fa-IR')}
                </div>
              </div>
            </div>
            <Badge variant={isRunning ? 'default' : 'secondary'} className="px-4 py-2">
              {isRunning ? 'در حال اجرا' : 'متوقف'}
            </Badge>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handleStartStop}
              className={`flex-1 ${isRunning ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}
              disabled={accountStatus.isSuspended}
            >
              {isRunning ? (
                <>
                  <Pause className="h-4 w-4 ml-2" />
                  توقف ربات
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 ml-2" />
                  شروع ربات
                </>
              )}
            </Button>
            
            <Button variant="outline" size="default">
              <Settings className="h-4 w-4 ml-2" />
              تنظیمات کلی
            </Button>
            
            <Button variant="outline" size="default">
              <Shield className="h-4 w-4 ml-2" />
              امنیت
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Suspension Alert */}
      {accountStatus.isSuspended && (
        <Alert className="border-red-500 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <div className="font-medium mb-2">ربات به دلیل امنیتی متوقف شده است</div>
            <div className="text-sm mb-3">
              دلیل: {accountStatus.suspensionReason}
            </div>
            <div className="flex items-center gap-2 text-sm">
              <RotateCcw className="h-4 w-4" />
              راه‌اندازی مجدد خودکار در چند ساعت آینده انجام خواهد شد
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Quick Stats */}
      <Card>
        <CardHeader>
          <CardTitle>آمار سریع</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="text-center p-3 bg-blue-50 rounded-lg">
              <div className="text-xl font-bold text-blue-600">
                {accountStatus.hourlyActions.follows}
              </div>
              <div className="text-xs text-gray-600">فالو (ساعتی)</div>
            </div>
            
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="text-xl font-bold text-green-600">
                {accountStatus.hourlyActions.unfollows}
              </div>
              <div className="text-xs text-gray-600">آنفالو (ساعتی)</div>
            </div>
            
            <div className="text-center p-3 bg-red-50 rounded-lg">
              <div className="text-xl font-bold text-red-600">
                {accountStatus.hourlyActions.likes}
              </div>
              <div className="text-xs text-gray-600">لایک (ساعتی)</div>
            </div>
            
            <div className="text-center p-3 bg-purple-50 rounded-lg">
              <div className="text-xl font-bold text-purple-600">
                {accountStatus.hourlyActions.comments}
              </div>
              <div className="text-xs text-gray-600">کامنت (ساعتی)</div>
            </div>
            
            <div className="text-center p-3 bg-orange-50 rounded-lg">
              <div className="text-xl font-bold text-orange-600">
                {accountStatus.hourlyActions.dm}
              </div>
              <div className="text-xs text-gray-600">پیام (ساعتی)</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}