import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { User, MapPin, Briefcase, Target, Clock, Hash } from 'lucide-react';
import { AccountConfig, AccountManager } from '@/lib/account-config';

interface AccountSetupProps {
  accountManager: AccountManager;
  onConfigSaved: (config: AccountConfig) => void;
}

export function AccountSetup({ accountManager, onConfigSaved }: AccountSetupProps) {
  const [config, setConfig] = useState<AccountConfig>({
    username: '',
    password: '',
    businessType: '',
    targetLocation: 'شیراز',
    targetKeywords: [],
    businessDescription: '',
    targetAudience: {
      minFollowers: 100,
      maxFollowers: 10000,
      engagementRate: 2
    },
    workingHours: {
      start: '09:00',
      end: '18:00',
      timezone: 'Asia/Tehran'
    }
  });

  const [customKeyword, setCustomKeyword] = useState('');
  const [recommendedHashtags, setRecommendedHashtags] = useState<string[]>([]);
  const [recommendedComments, setRecommendedComments] = useState<string[]>([]);

  const businessTypes = [
    'تصفیه آب',
    'رستوران',
    'آرایشگاه',
    'پوشاک',
    'املاک',
    'خودرو',
    'آموزشی',
    'پزشکی',
    'ورزشی',
    'فناوری'
  ];

  const iranianCities = [
    'تهران', 'مشهد', 'اصفهان', 'شیراز', 'تبریز', 'کرج', 'اهواز', 'قم',
    'کرمانشاه', 'ارومیه', 'رشت', 'زاهدان', 'همدان', 'کرمان', 'یزد'
  ];

  const handleBusinessTypeChange = (businessType: string) => {
    setConfig(prev => ({ ...prev, businessType }));
    
    // Generate recommendations
    const hashtags = accountManager.getRecommendedHashtags(businessType, config.targetLocation);
    const comments = accountManager.getRecommendedComments(businessType);
    
    setRecommendedHashtags(hashtags);
    setRecommendedComments(comments);
  };

  const handleLocationChange = (location: string) => {
    setConfig(prev => ({ ...prev, targetLocation: location }));
    
    if (config.businessType) {
      const hashtags = accountManager.getRecommendedHashtags(config.businessType, location);
      setRecommendedHashtags(hashtags);
    }
  };

  const addKeyword = () => {
    if (customKeyword && !config.targetKeywords.includes(customKeyword)) {
      setConfig(prev => ({
        ...prev,
        targetKeywords: [...prev.targetKeywords, customKeyword]
      }));
      setCustomKeyword('');
    }
  };

  const removeKeyword = (keyword: string) => {
    setConfig(prev => ({
      ...prev,
      targetKeywords: prev.targetKeywords.filter(k => k !== keyword)
    }));
  };

  const handleSave = () => {
    accountManager.setAccountConfig(config);
    onConfigSaved(config);
  };

  return (
    <div className="space-y-6">
      {/* Account Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            اطلاعات حساب اینستاگرام
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="username">نام کاربری</Label>
              <Input
                id="username"
                value={config.username}
                onChange={(e) => setConfig(prev => ({ ...prev, username: e.target.value }))}
                placeholder="your_instagram_username"
              />
            </div>
            <div>
              <Label htmlFor="password">رمز عبور</Label>
              <Input
                id="password"
                type="password"
                value={config.password}
                onChange={(e) => setConfig(prev => ({ ...prev, password: e.target.value }))}
                placeholder="رمز عبور اینستاگرام"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Business Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="h-5 w-5" />
            اطلاعات کسب و کار
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>نوع کسب و کار</Label>
              <Select value={config.businessType} onValueChange={handleBusinessTypeChange}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  {businessTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>شهر هدف</Label>
              <Select value={config.targetLocation} onValueChange={handleLocationChange}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب شهر" />
                </SelectTrigger>
                <SelectContent>
                  {iranianCities.map(city => (
                    <SelectItem key={city} value={city}>{city}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="businessDescription">توضیحات کسب و کار</Label>
            <Textarea
              id="businessDescription"
              value={config.businessDescription}
              onChange={(e) => setConfig(prev => ({ ...prev, businessDescription: e.target.value }))}
              placeholder="مثال: تصفیه آب خانگی و صنعتی در شیراز"
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Target Keywords */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Hash className="h-5 w-5" />
            کلمات کلیدی هدف
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={customKeyword}
              onChange={(e) => setCustomKeyword(e.target.value)}
              placeholder="کلمه کلیدی جدید"
              onKeyPress={(e) => e.key === 'Enter' && addKeyword()}
            />
            <Button onClick={addKeyword}>افزودن</Button>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {config.targetKeywords.map(keyword => (
              <Badge key={keyword} variant="secondary" className="cursor-pointer" onClick={() => removeKeyword(keyword)}>
                {keyword} ×
              </Badge>
            ))}
          </div>

          {recommendedHashtags.length > 0 && (
            <div>
              <Label>هشتگ‌های پیشنهادی:</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {recommendedHashtags.map(hashtag => (
                  <Badge key={hashtag} variant="outline" className="text-blue-600">
                    {hashtag}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Target Audience */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            مخاطب هدف
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="minFollowers">حداقل فالوور</Label>
              <Input
                id="minFollowers"
                type="number"
                value={config.targetAudience.minFollowers}
                onChange={(e) => setConfig(prev => ({
                  ...prev,
                  targetAudience: { ...prev.targetAudience, minFollowers: parseInt(e.target.value) }
                }))}
              />
            </div>
            <div>
              <Label htmlFor="maxFollowers">حداکثر فالوور</Label>
              <Input
                id="maxFollowers"
                type="number"
                value={config.targetAudience.maxFollowers}
                onChange={(e) => setConfig(prev => ({
                  ...prev,
                  targetAudience: { ...prev.targetAudience, maxFollowers: parseInt(e.target.value) }
                }))}
              />
            </div>
            <div>
              <Label htmlFor="engagementRate">نرخ تعامل (درصد)</Label>
              <Input
                id="engagementRate"
                type="number"
                step="0.1"
                value={config.targetAudience.engagementRate}
                onChange={(e) => setConfig(prev => ({
                  ...prev,
                  targetAudience: { ...prev.targetAudience, engagementRate: parseFloat(e.target.value) }
                }))}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Working Hours */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            ساعات کاری ربات
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="startTime">شروع کار</Label>
              <Input
                id="startTime"
                type="time"
                value={config.workingHours.start}
                onChange={(e) => setConfig(prev => ({
                  ...prev,
                  workingHours: { ...prev.workingHours, start: e.target.value }
                }))}
              />
            </div>
            <div>
              <Label htmlFor="endTime">پایان کار</Label>
              <Input
                id="endTime"
                type="time"
                value={config.workingHours.end}
                onChange={(e) => setConfig(prev => ({
                  ...prev,
                  workingHours: { ...prev.workingHours, end: e.target.value }
                }))}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recommended Comments */}
      {recommendedComments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>کامنت‌های پیشنهادی</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {recommendedComments.map((comment, index) => (
                <div key={index} className="p-2 bg-gray-50 rounded text-sm">
                  {comment}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} size="lg" className="px-8">
          <MapPin className="h-4 w-4 ml-2" />
          ذخیره تنظیمات
        </Button>
      </div>

      {/* Info Alert */}
      <Alert>
        <AlertDescription>
          پس از ذخیره تنظیمات، ربات به طور خودکار کاربران مرتبط با کسب و کار شما در {config.targetLocation} را پیدا کرده و عملیات مناسب را انجام خواهد داد.
        </AlertDescription>
      </Alert>
    </div>
  );
}