import { InstagramSafetyMonitor } from './instagram-safety';

export interface BotService {
  id: string;
  name: string;
  description: string;
  icon: string;
  isActive: boolean;
  isRunning: boolean;
  settings: Record<string, any>;
  lastRun?: Date;
  nextRun?: Date;
  statistics: {
    totalRuns: number;
    successfulRuns: number;
    failedRuns: number;
    lastResult?: string;
  };
}

export interface BotTask {
  id: string;
  serviceId: string;
  type: 'follow' | 'unfollow' | 'like' | 'comment' | 'dm' | 'story_view';
  target: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'paused';
  scheduledAt: Date;
  completedAt?: Date;
  result?: string;
  retryCount: number;
}

export class InstagramBotManager {
  private services: Map<string, BotService> = new Map();
  private tasks: BotTask[] = [];
  private safetyMonitor: InstagramSafetyMonitor;
  private isRunning = false;
  private taskInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.safetyMonitor = new InstagramSafetyMonitor();
    this.initializeServices();
  }

  private initializeServices(): void {
    const defaultServices: BotService[] = [
      {
        id: 'auto-follow',
        name: 'دنبال کردن خودکار',
        description: 'دنبال کردن خودکار کاربران بر اساس هشتگ‌ها و مکان‌ها',
        icon: 'UserPlus',
        isActive: false,
        isRunning: false,
        settings: {
          hashtags: ['#photography', '#art'],
          locations: [],
          maxFollowsPerDay: 150,
          delayBetweenFollows: 30,
          targetFollowerRange: { min: 100, max: 10000 },
        },
        statistics: { totalRuns: 0, successfulRuns: 0, failedRuns: 0 },
      },
      {
        id: 'auto-unfollow',
        name: 'آنفالو خودکار',
        description: 'آنفالو کردن کاربرانی که فالو بک نکرده‌اند',
        icon: 'UserMinus',
        isActive: false,
        isRunning: false,
        settings: {
          unfollowAfterDays: 3,
          keepFollowersWhoFollowBack: true,
          maxUnfollowsPerDay: 200,
          delayBetweenUnfollows: 25,
        },
        statistics: { totalRuns: 0, successfulRuns: 0, failedRuns: 0 },
      },
      {
        id: 'auto-like',
        name: 'لایک خودکار',
        description: 'لایک کردن پست‌های مرتبط با هشتگ‌های مورد نظر',
        icon: 'Heart',
        isActive: false,
        isRunning: false,
        settings: {
          hashtags: ['#photography', '#art'],
          maxLikesPerDay: 500,
          delayBetweenLikes: 15,
          avoidRecentlyLiked: true,
        },
        statistics: { totalRuns: 0, successfulRuns: 0, failedRuns: 0 },
      },
      {
        id: 'auto-comment',
        name: 'کامنت خودکار',
        description: 'کامنت گذاشتن خودکار با متن‌های از پیش تعریف شده',
        icon: 'MessageCircle',
        isActive: false,
        isRunning: false,
        settings: {
          hashtags: ['#photography'],
          comments: ['عالی! 👏', 'فوق‌العاده 🔥', 'بسیار زیبا ❤️'],
          maxCommentsPerDay: 50,
          delayBetweenComments: 120,
        },
        statistics: { totalRuns: 0, successfulRuns: 0, failedRuns: 0 },
      },
      {
        id: 'story-viewer',
        name: 'مشاهده استوری',
        description: 'مشاهده خودکار استوری‌های کاربران هدف',
        icon: 'Eye',
        isActive: false,
        isRunning: false,
        settings: {
          targetUsers: [],
          maxStoriesPerDay: 100,
          delayBetweenViews: 10,
        },
        statistics: { totalRuns: 0, successfulRuns: 0, failedRuns: 0 },
      },
      {
        id: 'dm-sender',
        name: 'ارسال پیام خصوصی',
        description: 'ارسال پیام‌های خصوصی به کاربران جدید',
        icon: 'Send',
        isActive: false,
        isRunning: false,
        settings: {
          messageTemplates: ['سلام! پیجتون رو دیدم، خیلی قشنگه! 😊'],
          maxDMsPerDay: 30,
          delayBetweenDMs: 300,
          onlyToNewFollowers: true,
        },
        statistics: { totalRuns: 0, successfulRuns: 0, failedRuns: 0 },
      },
    ];

    defaultServices.forEach(service => {
      this.services.set(service.id, service);
    });
  }

  startBot(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;
    this.safetyMonitor.startMonitoring();
    
    // Start task processor
    this.taskInterval = setInterval(() => {
      this.processTasks();
    }, 5000); // Process tasks every 5 seconds
    
    console.log('🤖 ربات اینستاگرام راه‌اندازی شد');
  }

  stopBot(): void {
    if (!this.isRunning) return;
    
    this.isRunning = false;
    this.safetyMonitor.stopMonitoring();
    
    if (this.taskInterval) {
      clearInterval(this.taskInterval);
    }
    
    // Stop all running services
    this.services.forEach(service => {
      service.isRunning = false;
    });
    
    console.log('🛑 ربات اینستاگرام متوقف شد');
  }

  toggleService(serviceId: string): void {
    const service = this.services.get(serviceId);
    if (!service) return;
    
    service.isActive = !service.isActive;
    
    if (service.isActive && this.isRunning) {
      this.scheduleServiceTasks(service);
    }
  }

  private scheduleServiceTasks(service: BotService): void {
    const now = new Date();
    const nextRun = new Date(now.getTime() + Math.random() * 300000 + 60000); // 1-6 minutes
    
    service.nextRun = nextRun;
    
    // Create tasks based on service type
    switch (service.id) {
      case 'auto-follow':
        this.createFollowTasks(service);
        break;
      case 'auto-unfollow':
        this.createUnfollowTasks(service);
        break;
      case 'auto-like':
        this.createLikeTasks(service);
        break;
      case 'auto-comment':
        this.createCommentTasks(service);
        break;
      case 'story-viewer':
        this.createStoryViewTasks(service);
        break;
      case 'dm-sender':
        this.createDMTasks(service);
        break;
    }
  }

  private createFollowTasks(service: BotService): void {
    const maxFollows = Math.min(service.settings.maxFollowsPerDay, 20); // Limit per batch
    
    for (let i = 0; i < maxFollows; i++) {
      const task: BotTask = {
        id: `follow-${Date.now()}-${i}`,
        serviceId: service.id,
        type: 'follow',
        target: `user_${Math.floor(Math.random() * 10000)}`, // Simulated target
        status: 'pending',
        scheduledAt: new Date(Date.now() + i * service.settings.delayBetweenFollows * 1000),
        retryCount: 0,
      };
      
      this.tasks.push(task);
    }
  }

  private createUnfollowTasks(service: BotService): void {
    const maxUnfollows = Math.min(service.settings.maxUnfollowsPerDay, 25);
    
    for (let i = 0; i < maxUnfollows; i++) {
      const task: BotTask = {
        id: `unfollow-${Date.now()}-${i}`,
        serviceId: service.id,
        type: 'unfollow',
        target: `user_${Math.floor(Math.random() * 10000)}`,
        status: 'pending',
        scheduledAt: new Date(Date.now() + i * service.settings.delayBetweenUnfollows * 1000),
        retryCount: 0,
      };
      
      this.tasks.push(task);
    }
  }

  private createLikeTasks(service: BotService): void {
    const maxLikes = Math.min(service.settings.maxLikesPerDay, 60);
    
    for (let i = 0; i < maxLikes; i++) {
      const task: BotTask = {
        id: `like-${Date.now()}-${i}`,
        serviceId: service.id,
        type: 'like',
        target: `post_${Math.floor(Math.random() * 10000)}`,
        status: 'pending',
        scheduledAt: new Date(Date.now() + i * service.settings.delayBetweenLikes * 1000),
        retryCount: 0,
      };
      
      this.tasks.push(task);
    }
  }

  private createCommentTasks(service: BotService): void {
    const maxComments = Math.min(service.settings.maxCommentsPerDay, 15);
    
    for (let i = 0; i < maxComments; i++) {
      const task: BotTask = {
        id: `comment-${Date.now()}-${i}`,
        serviceId: service.id,
        type: 'comment',
        target: `post_${Math.floor(Math.random() * 10000)}`,
        status: 'pending',
        scheduledAt: new Date(Date.now() + i * service.settings.delayBetweenComments * 1000),
        retryCount: 0,
      };
      
      this.tasks.push(task);
    }
  }

  private createStoryViewTasks(service: BotService): void {
    const maxViews = Math.min(service.settings.maxStoriesPerDay, 30);
    
    for (let i = 0; i < maxViews; i++) {
      const task: BotTask = {
        id: `story-${Date.now()}-${i}`,
        serviceId: service.id,
        type: 'story_view',
        target: `story_${Math.floor(Math.random() * 10000)}`,
        status: 'pending',
        scheduledAt: new Date(Date.now() + i * service.settings.delayBetweenViews * 1000),
        retryCount: 0,
      };
      
      this.tasks.push(task);
    }
  }

  private createDMTasks(service: BotService): void {
    const maxDMs = Math.min(service.settings.maxDMsPerDay, 10);
    
    for (let i = 0; i < maxDMs; i++) {
      const task: BotTask = {
        id: `dm-${Date.now()}-${i}`,
        serviceId: service.id,
        type: 'dm',
        target: `user_${Math.floor(Math.random() * 10000)}`,
        status: 'pending',
        scheduledAt: new Date(Date.now() + i * service.settings.delayBetweenDMs * 1000),
        retryCount: 0,
      };
      
      this.tasks.push(task);
    }
  }

  private async processTasks(): Promise<void> {
    const accountStatus = this.safetyMonitor.getAccountStatus();
    
    if (accountStatus.isSuspended || !this.isRunning) {
      return;
    }
    
    const now = new Date();
    const readyTasks = this.tasks.filter(
      task => task.status === 'pending' && task.scheduledAt <= now
    );
    
    for (const task of readyTasks.slice(0, 3)) { // Process max 3 tasks at once
      if (!this.safetyMonitor.canPerformAction(this.mapTaskTypeToAction(task.type))) {
        task.status = 'paused';
        continue;
      }
      
      await this.executeTask(task);
    }
  }

  private mapTaskTypeToAction(taskType: BotTask['type']): keyof InstagramSafetyMonitor['getAccountStatus']['hourlyActions'] {
    switch (taskType) {
      case 'follow': return 'follows';
      case 'unfollow': return 'unfollows';
      case 'like': return 'likes';
      case 'comment': return 'comments';
      case 'dm': return 'dm';
      default: return 'likes';
    }
  }

  private async executeTask(task: BotTask): Promise<void> {
    task.status = 'running';
    
    try {
      // Simulate task execution
      await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 1000));
      
      // Record the action with safety monitor
      this.safetyMonitor.recordAction(this.mapTaskTypeToAction(task.type));
      
      // Simulate success/failure
      const success = Math.random() > 0.1; // 90% success rate
      
      if (success) {
        task.status = 'completed';
        task.completedAt = new Date();
        task.result = 'موفق';
        
        // Update service statistics
        const service = this.services.get(task.serviceId);
        if (service) {
          service.statistics.successfulRuns++;
          service.statistics.totalRuns++;
          service.statistics.lastResult = 'موفق';
          service.lastRun = new Date();
        }
      } else {
        throw new Error('عملیات ناموفق');
      }
    } catch (error) {
      task.status = 'failed';
      task.result = error instanceof Error ? error.message : 'خطای نامشخص';
      task.retryCount++;
      
      // Update service statistics
      const service = this.services.get(task.serviceId);
      if (service) {
        service.statistics.failedRuns++;
        service.statistics.totalRuns++;
        service.statistics.lastResult = 'ناموفق';
      }
      
      // Retry logic
      if (task.retryCount < 3) {
        task.status = 'pending';
        task.scheduledAt = new Date(Date.now() + 300000); // Retry after 5 minutes
      }
    }
  }

  getServices(): BotService[] {
    return Array.from(this.services.values());
  }

  getService(serviceId: string): BotService | undefined {
    return this.services.get(serviceId);
  }

  updateServiceSettings(serviceId: string, settings: Record<string, any>): void {
    const service = this.services.get(serviceId);
    if (service) {
      service.settings = { ...service.settings, ...settings };
    }
  }

  getTasks(): BotTask[] {
    return [...this.tasks];
  }

  getAccountStatus() {
    return this.safetyMonitor.getAccountStatus();
  }

  getSafetyLimits() {
    return this.safetyMonitor.getSafetyLimits();
  }

  updateSafetyLimits(limits: any) {
    this.safetyMonitor.updateSafetyLimits(limits);
  }

  isRunning(): boolean {
    return this.isRunning;
  }
}