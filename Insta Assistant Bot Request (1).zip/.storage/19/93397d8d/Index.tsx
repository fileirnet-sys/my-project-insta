import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BotControlPanel } from '@/components/BotControlPanel';
import { BotServiceCard } from '@/components/BotServiceCard';
import { SafetyMonitor } from '@/components/SafetyMonitor';
import { InstagramBotManager } from '@/lib/bot-services';
import { Bot, Shield, BarChart3, Settings } from 'lucide-react';

const Index = () => {
  const [botManager] = useState(() => new InstagramBotManager());
  const [services, setServices] = useState(botManager.getServices());
  const [accountStatus, setAccountStatus] = useState(botManager.getAccountStatus());
  const [safetyLimits, setSafetyLimits] = useState(botManager.getSafetyLimits());

  useEffect(() => {
    const interval = setInterval(() => {
      setServices(botManager.getServices());
      setAccountStatus(botManager.getAccountStatus());
      setSafetyLimits(botManager.getSafetyLimits());
    }, 1000);

    return () => clearInterval(interval);
  }, [botManager]);

  const handleServiceToggle = (serviceId: string) => {
    botManager.toggleService(serviceId);
    setServices(botManager.getServices());
  };

  const handleServiceSettings = (serviceId: string) => {
    // TODO: Open settings modal for the service
    console.log('Opening settings for service:', serviceId);
  };

  const handleStatusChange = () => {
    setServices(botManager.getServices());
    setAccountStatus(botManager.getAccountStatus());
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50" dir="rtl">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            🤖 ربات هوشمند اینستاگرام
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            سیستم کاملاً خودکار مدیریت اینستاگرام با قابلیت‌های پیشرفته امنیتی و راه‌اندازی مجدد خودکار
          </p>
        </div>

        {/* Main Control Panel */}
        <div className="mb-8">
          <BotControlPanel 
            botManager={botManager} 
            onStatusChange={handleStatusChange}
          />
        </div>

        {/* Tabs */}
        <Tabs defaultValue="services" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="services" className="flex items-center gap-2">
              <Bot className="h-4 w-4" />
              خدمات ربات
            </TabsTrigger>
            <TabsTrigger value="safety" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              نظارت امنیتی
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              آمار و گزارش
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              تنظیمات
            </TabsTrigger>
          </TabsList>

          {/* Services Tab */}
          <TabsContent value="services" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((service) => (
                <BotServiceCard
                  key={service.id}
                  service={service}
                  onToggle={handleServiceToggle}
                  onSettings={handleServiceSettings}
                />
              ))}
            </div>
          </TabsContent>

          {/* Safety Monitor Tab */}
          <TabsContent value="safety" className="space-y-6">
            <SafetyMonitor 
              accountStatus={accountStatus}
              safetyLimits={safetyLimits}
            />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((service) => (
                <div key={service.id} className="bg-white p-6 rounded-lg shadow-sm border">
                  <h3 className="font-semibold mb-4">{service.name}</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">کل اجرا:</span>
                      <span className="font-medium">{service.statistics.totalRuns}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">موفق:</span>
                      <span className="font-medium text-green-600">{service.statistics.successfulRuns}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">ناموفق:</span>
                      <span className="font-medium text-red-600">{service.statistics.failedRuns}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">نرخ موفقیت:</span>
                      <span className="font-medium">
                        {service.statistics.totalRuns > 0 
                          ? Math.round((service.statistics.successfulRuns / service.statistics.totalRuns) * 100)
                          : 0}%
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border">
              <h3 className="text-xl font-semibold mb-4">تنظیمات امنیتی</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-3">محدودیت‌های ساعتی</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>دنبال کردن:</span>
                      <span className="font-medium">{safetyLimits.followsPerHour}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>آنفالو:</span>
                      <span className="font-medium">{safetyLimits.unfollowsPerHour}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>لایک:</span>
                      <span className="font-medium">{safetyLimits.likesPerHour}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>کامنت:</span>
                      <span className="font-medium">{safetyLimits.commentsPerHour}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>پیام خصوصی:</span>
                      <span className="font-medium">{safetyLimits.dmPerHour}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-3">محدودیت‌های روزانه</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>دنبال کردن:</span>
                      <span className="font-medium">{safetyLimits.followsPerDay}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>آنفالو:</span>
                      <span className="font-medium">{safetyLimits.unfollowsPerDay}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>لایک:</span>
                      <span className="font-medium">{safetyLimits.likesPerDay}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>کامنت:</span>
                      <span className="font-medium">{safetyLimits.commentsPerDay}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>پیام خصوصی:</span>
                      <span className="font-medium">{safetyLimits.dmPerDay}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm border">
              <h3 className="text-xl font-semibold mb-4">ویژگی‌های امنیتی</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                  <div>
                    <h4 className="font-medium text-green-800">نظارت خودکار</h4>
                    <p className="text-sm text-green-600">سیستم به طور مداوم وضعیت حساب را بررسی می‌کند</p>
                  </div>
                  <div className="text-green-600">✅</div>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                  <div>
                    <h4 className="font-medium text-blue-800">توقف هوشمند</h4>
                    <p className="text-sm text-blue-600">در صورت تشخیص خطر، ربات خودکار متوقف می‌شود</p>
                  </div>
                  <div className="text-blue-600">✅</div>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                  <div>
                    <h4 className="font-medium text-purple-800">راه‌اندازی مجدد خودکار</h4>
                    <p className="text-sm text-purple-600">پس از چند ساعت، سیستم خودکار راه‌اندازی مجدد می‌شود</p>
                  </div>
                  <div className="text-purple-600">✅</div>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-orange-50 rounded-lg">
                  <div>
                    <h4 className="font-medium text-orange-800">هشدارهای پیشرفته</h4>
                    <p className="text-sm text-orange-600">سیستم قبل از رسیدن به حد خطر هشدار می‌دهد</p>
                  </div>
                  <div className="text-orange-600">✅</div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-500">
          <p>© 2024 ربات هوشمند اینستاگرام - تمامی حقوق محفوظ است</p>
          <p className="text-sm mt-2">
            این سیستم با رعایت کامل قوانین اینستاگرام و اصول امنیتی طراحی شده است
          </p>
        </div>
      </div>
    </div>
  );
};

export default Index;