import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  UserPlus, 
  UserMinus, 
  Heart, 
  MessageCircle, 
  Eye, 
  Send, 
  Settings,
  Play,
  Pause,
  TrendingUp,
  Clock
} from 'lucide-react';
import { BotService } from '@/lib/bot-services';

interface BotServiceCardProps {
  service: BotService;
  onToggle: (serviceId: string) => void;
  onSettings: (serviceId: string) => void;
}

const iconMap = {
  UserPlus,
  UserMinus,
  Heart,
  MessageCircle,
  Eye,
  Send,
};

export function BotServiceCard({ service, onToggle, onSettings }: BotServiceCardProps) {
  const IconComponent = iconMap[service.icon as keyof typeof iconMap] || UserPlus;
  
  const formatDate = (date?: Date) => {
    if (!date) return 'هرگز';
    return date.toLocaleString('fa-IR');
  };

  const getSuccessRate = () => {
    if (service.statistics.totalRuns === 0) return 0;
    return Math.round((service.statistics.successfulRuns / service.statistics.totalRuns) * 100);
  };

  return (
    <Card className={`transition-all duration-200 ${service.isActive ? 'ring-2 ring-blue-500 bg-blue-50/50' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${service.isActive ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'}`}>
              <IconComponent className="h-5 w-5" />
            </div>
            <div>
              <CardTitle className="text-lg">{service.name}</CardTitle>
              <p className="text-sm text-gray-600 mt-1">{service.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {service.isRunning && (
              <Badge variant="default" className="bg-green-100 text-green-800">
                <Play className="h-3 w-3 ml-1" />
                در حال اجرا
              </Badge>
            )}
            <Switch
              checked={service.isActive}
              onCheckedChange={() => onToggle(service.id)}
            />
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Statistics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{service.statistics.totalRuns}</div>
            <div className="text-xs text-gray-600">کل اجرا</div>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{getSuccessRate()}%</div>
            <div className="text-xs text-gray-600">نرخ موفقیت</div>
          </div>
        </div>

        {/* Status Information */}
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">آخرین اجرا:</span>
            <span>{formatDate(service.lastRun)}</span>
          </div>
          {service.nextRun && (
            <div className="flex justify-between">
              <span className="text-gray-600">اجرای بعدی:</span>
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {formatDate(service.nextRun)}
              </span>
            </div>
          )}
          {service.statistics.lastResult && (
            <div className="flex justify-between">
              <span className="text-gray-600">آخرین نتیجه:</span>
              <Badge variant={service.statistics.lastResult === 'موفق' ? 'default' : 'destructive'}>
                {service.statistics.lastResult}
              </Badge>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onSettings(service.id)}
            className="flex-1"
          >
            <Settings className="h-4 w-4 ml-2" />
            تنظیمات
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
          >
            <TrendingUp className="h-4 w-4 ml-2" />
            آمار
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}