import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, AlertTriangle, CheckCircle, XCircle, Clock } from 'lucide-react';
import { AccountStatus, SafetyLimits } from '@/lib/instagram-safety';

interface SafetyMonitorProps {
  accountStatus: AccountStatus;
  safetyLimits: SafetyLimits;
}

export function SafetyMonitor({ accountStatus, safetyLimits }: SafetyMonitorProps) {
  const getWarningColor = (level: AccountStatus['warningLevel']) => {
    switch (level) {
      case 'safe': return 'text-green-600';
      case 'warning': return 'text-yellow-600';
      case 'danger': return 'text-orange-600';
      case 'critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getWarningIcon = (level: AccountStatus['warningLevel']) => {
    switch (level) {
      case 'safe': return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
      case 'danger': return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      case 'critical': return <XCircle className="h-5 w-5 text-red-600" />;
      default: return <Shield className="h-5 w-5 text-gray-600" />;
    }
  };

  const getWarningText = (level: AccountStatus['warningLevel']) => {
    switch (level) {
      case 'safe': return 'ایمن';
      case 'warning': return 'هشدار';
      case 'danger': return 'خطر';
      case 'critical': return 'بحرانی';
      default: return 'نامشخص';
    }
  };

  const calculateUsagePercentage = (current: number, limit: number) => {
    return Math.min((current / limit) * 100, 100);
  };

  const formatNextAllowedTime = (date: Date) => {
    const now = new Date();
    const diff = date.getTime() - now.getTime();
    
    if (diff <= 0) return 'اکنون';
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours} ساعت و ${minutes} دقیقه`;
    }
    return `${minutes} دقیقه`;
  };

  return (
    <div className="space-y-6">
      {/* Account Status Alert */}
      {accountStatus.isSuspended && (
        <Alert className="border-red-500 bg-red-50">
          <XCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>حساب متوقف شده:</strong> {accountStatus.suspensionReason}
            <br />
            <div className="flex items-center mt-2">
              <Clock className="h-4 w-4 ml-2" />
              راه‌اندازی مجدد در: {formatNextAllowedTime(accountStatus.nextAllowedAction)}
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Safety Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            وضعیت امنیتی حساب
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              {getWarningIcon(accountStatus.warningLevel)}
              <span className={`font-medium ${getWarningColor(accountStatus.warningLevel)}`}>
                {getWarningText(accountStatus.warningLevel)}
              </span>
            </div>
            <Badge variant={accountStatus.isActive ? 'default' : 'secondary'}>
              {accountStatus.isActive ? 'فعال' : 'غیرفعال'}
            </Badge>
          </div>
          
          <div className="text-sm text-gray-600">
            آخرین فعالیت: {accountStatus.lastActivity.toLocaleString('fa-IR')}
          </div>
        </CardContent>
      </Card>

      {/* Hourly Usage */}
      <Card>
        <CardHeader>
          <CardTitle>استفاده ساعتی</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>دنبال کردن</span>
                <span>{accountStatus.hourlyActions.follows}/{safetyLimits.followsPerHour}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.hourlyActions.follows, safetyLimits.followsPerHour)} 
                className="h-2"
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>آنفالو</span>
                <span>{accountStatus.hourlyActions.unfollows}/{safetyLimits.unfollowsPerHour}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.hourlyActions.unfollows, safetyLimits.unfollowsPerHour)} 
                className="h-2"
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>لایک</span>
                <span>{accountStatus.hourlyActions.likes}/{safetyLimits.likesPerHour}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.hourlyActions.likes, safetyLimits.likesPerHour)} 
                className="h-2"
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>کامنت</span>
                <span>{accountStatus.hourlyActions.comments}/{safetyLimits.commentsPerHour}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.hourlyActions.comments, safetyLimits.commentsPerHour)} 
                className="h-2"
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>پیام خصوصی</span>
                <span>{accountStatus.hourlyActions.dm}/{safetyLimits.dmPerHour}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.hourlyActions.dm, safetyLimits.dmPerHour)} 
                className="h-2"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Daily Usage */}
      <Card>
        <CardHeader>
          <CardTitle>استفاده روزانه</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>دنبال کردن</span>
                <span>{accountStatus.dailyActions.follows}/{safetyLimits.followsPerDay}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.dailyActions.follows, safetyLimits.followsPerDay)} 
                className="h-2"
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>آنفالو</span>
                <span>{accountStatus.dailyActions.unfollows}/{safetyLimits.unfollowsPerDay}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.dailyActions.unfollows, safetyLimits.unfollowsPerDay)} 
                className="h-2"
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>لایک</span>
                <span>{accountStatus.dailyActions.likes}/{safetyLimits.likesPerDay}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.dailyActions.likes, safetyLimits.likesPerDay)} 
                className="h-2"
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>کامنت</span>
                <span>{accountStatus.dailyActions.comments}/{safetyLimits.commentsPerDay}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.dailyActions.comments, safetyLimits.commentsPerDay)} 
                className="h-2"
              />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>پیام خصوصی</span>
                <span>{accountStatus.dailyActions.dm}/{safetyLimits.dmPerDay}</span>
              </div>
              <Progress 
                value={calculateUsagePercentage(accountStatus.dailyActions.dm, safetyLimits.dmPerDay)} 
                className="h-2"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}