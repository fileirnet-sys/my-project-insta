export interface AccountConfig {
  username: string;
  password: string;
  businessType: string;
  targetLocation: string;
  targetKeywords: string[];
  businessDescription: string;
  targetAudience: {
    minFollowers: number;
    maxFollowers: number;
    engagementRate: number;
  };
  workingHours: {
    start: string;
    end: string;
    timezone: string;
  };
}

export interface TargetProfile {
  username: string;
  fullName: string;
  followerCount: number;
  followingCount: number;
  postCount: number;
  engagementRate: number;
  location?: string;
  bio?: string;
  isBusinessAccount: boolean;
  lastActivity: Date;
  relevanceScore: number;
}

export class AccountManager {
  private config: AccountConfig | null = null;
  private targetProfiles: TargetProfile[] = [];

  setAccountConfig(config: AccountConfig): void {
    this.config = config;
    localStorage.setItem('instagram_bot_config', JSON.stringify(config));
  }

  getAccountConfig(): AccountConfig | null {
    if (this.config) return this.config;
    
    const stored = localStorage.getItem('instagram_bot_config');
    if (stored) {
      this.config = JSON.parse(stored);
    }
    return this.config;
  }

  generateTargetKeywords(businessType: string, location: string): string[] {
    const businessKeywords: Record<string, string[]> = {
      'تصفیه آب': [
        'تصفیه_آب', 'دستگاه_تصفیه', 'آب_آشامیدنی', 'فیلتر_آب', 'تصفیه_خانگی',
        'دستگاه_آب', 'آب_سالم', 'تصفیه_صنعتی', 'فیلتر_خانگی', 'آب_معدنی'
      ],
      'رستوران': [
        'رستوران', 'غذا', 'آشپزی', 'کافه', 'فست_فود', 'غذای_سنتی'
      ],
      'آرایشگاه': [
        'آرایشگاه', 'زیبایی', 'مو', 'آرایش', 'پیرایش', 'سالن_زیبایی'
      ],
      'پوشاک': [
        'لباس', 'پوشاک', 'مد', 'فشن', 'استایل', 'برند'
      ]
    };

    const locationKeywords = [
      location,
      `${location}_شهر`,
      `کسب_و_کار_${location}`,
      `خدمات_${location}`
    ];

    const baseKeywords = businessKeywords[businessType] || [businessType];
    
    return [...baseKeywords, ...locationKeywords];
  }

  async findTargetProfiles(businessType: string, location: string, limit: number = 100): Promise<TargetProfile[]> {
    // Simulate finding target profiles based on location and business type
    const mockProfiles: TargetProfile[] = [];
    
    const keywords = this.generateTargetKeywords(businessType, location);
    
    for (let i = 0; i < limit; i++) {
      const profile: TargetProfile = {
        username: `${location}_user_${i + 1}`,
        fullName: `کاربر ${location} ${i + 1}`,
        followerCount: Math.floor(Math.random() * 5000) + 100,
        followingCount: Math.floor(Math.random() * 1000) + 50,
        postCount: Math.floor(Math.random() * 500) + 10,
        engagementRate: Math.random() * 10 + 1,
        location: location,
        bio: `ساکن ${location} - علاقه‌مند به ${businessType}`,
        isBusinessAccount: Math.random() > 0.7,
        lastActivity: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
        relevanceScore: this.calculateRelevanceScore(keywords, `ساکن ${location} - علاقه‌مند به ${businessType}`)
      };
      
      mockProfiles.push(profile);
    }
    
    // Sort by relevance score
    mockProfiles.sort((a, b) => b.relevanceScore - a.relevanceScore);
    
    this.targetProfiles = mockProfiles;
    return mockProfiles;
  }

  private calculateRelevanceScore(keywords: string[], bio: string): number {
    let score = 0;
    const bioLower = bio.toLowerCase();
    
    keywords.forEach(keyword => {
      if (bioLower.includes(keyword.toLowerCase())) {
        score += 10;
      }
    });
    
    // Add random factor for simulation
    score += Math.random() * 20;
    
    return Math.min(score, 100);
  }

  getTargetProfiles(): TargetProfile[] {
    return this.targetProfiles;
  }

  async searchByHashtag(hashtag: string): Promise<TargetProfile[]> {
    // Simulate hashtag search
    return this.findTargetProfiles('عمومی', 'شیراز', 50);
  }

  async searchByLocation(location: string): Promise<TargetProfile[]> {
    // Simulate location search
    return this.findTargetProfiles('عمومی', location, 50);
  }

  getRecommendedHashtags(businessType: string, location: string): string[] {
    const businessHashtags: Record<string, string[]> = {
      'تصفیه آب': [
        '#تصفیه_آب_شیراز',
        '#دستگاه_تصفیه_آب',
        '#آب_سالم_شیراز',
        '#فیلتر_آب_شیراز',
        '#تصفیه_خانگی',
        '#آب_آشامیدنی_شیراز',
        '#سلامت_آب',
        '#کیفیت_آب'
      ]
    };

    const locationHashtags = [
      `#${location}`,
      `#کسب_و_کار_${location}`,
      `#خدمات_${location}`,
      `#شهر_${location}`
    ];

    const baseHashtags = businessHashtags[businessType] || [`#${businessType}`];
    
    return [...baseHashtags, ...locationHashtags];
  }

  getRecommendedComments(businessType: string): string[] {
    const businessComments: Record<string, string[]> = {
      'تصفیه آب': [
        'سلامت آب خیلی مهمه! 💧',
        'دستگاه تصفیه آب عالی! 👌',
        'کیفیت آب بالا! ✨',
        'برای سلامتی آب مهم است 🙏',
        'آب سالم زندگی سالم 💙',
        'تصفیه آب ضروری است 👍'
      ]
    };

    return businessComments[businessType] || [
      'عالی! 👏',
      'فوق‌العاده 🔥',
      'بسیار زیبا ❤️',
      'کار خوبی! 👌',
      'موفق باشید 🙏'
    ];
  }
}