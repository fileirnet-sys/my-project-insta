export interface BotService {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'follower' | 'engagement' | 'analytics' | 'content';
  isActive: boolean;
}

export const botServices: BotService[] = [
  // Follower Management
  {
    id: 'follow-target',
    title: 'ربات فالو کردن پیج هدف',
    description: 'فالو کردن تارگت‌های مشخص شده',
    icon: '👥',
    category: 'follower',
    isActive: true
  },
  {
    id: 'unfollow-target',
    title: 'ربات آنفالو بدون برگشت',
    description: 'آنفالو کردن افرادی که فالوبک نکردند',
    icon: '👤',
    category: 'follower',
    isActive: true
  },
  {
    id: 'follow-followers',
    title: 'ربات فالو کردن فالوینگ‌های پیج هدف',
    description: 'فالو کردن فالوورهای کاربران هدف',
    icon: '🎯',
    category: 'follower',
    isActive: true
  },
  {
    id: 'unfollow-non-followers',
    title: 'ربات فالو کردن لایک کنندگان پیج هدف',
    description: 'فالو کردن کسانی که پست‌ها را لایک می‌کنند',
    icon: '❤️',
    category: 'follower',
    isActive: true
  },
  {
    id: 'follow-likers',
    title: 'ربات لایک و کامنت گذاشتن',
    description: 'لایک و کامنت خودکار روی پست‌ها',
    icon: '💬',
    category: 'engagement',
    isActive: true
  },
  {
    id: 'like-comment',
    title: 'ربات مخصوص گروه‌های حمایتی',
    description: 'مدیریت گروه‌های حمایت متقابل',
    icon: '🤝',
    category: 'engagement',
    isActive: true
  },
  
  // Engagement
  {
    id: 'story-viewer',
    title: 'ربات سوپر لایک آنلاین',
    description: 'لایک فوری پست‌های جدید',
    icon: '⚡',
    category: 'engagement',
    isActive: true
  },
  {
    id: 'auto-like',
    title: 'ربات آنریکوئست بدون بررسی',
    description: 'پذیرش خودکار درخواست‌های فالو',
    icon: '✅',
    category: 'engagement',
    isActive: true
  },
  {
    id: 'dm-sender',
    title: 'ربات آنفالو و آنریکوئست با بررسی تاریخ',
    description: 'مدیریت هوشمند فالوورها',
    icon: '📅',
    category: 'analytics',
    isActive: true
  },
  {
    id: 'check-followers',
    title: 'ربات چک کردن استوری و آکسپلور',
    description: 'مشاهده خودکار استوری‌ها و آکسپلور',
    icon: '👁️',
    category: 'content',
    isActive: true
  },
  {
    id: 'explore-stories',
    title: 'ربات ویو و خروج آنلاین',
    description: 'افزایش ویو پست‌ها',
    icon: '📊',
    category: 'analytics',
    isActive: true
  },
  {
    id: 'view-posts',
    title: 'ربات فالو کردن پیشنهادهای اینستاگرام',
    description: 'فالو کردن پیشنهادات اینستا',
    icon: '💡',
    category: 'follower',
    isActive: true
  },

  // Advanced Features
  {
    id: 'follow-likers-advanced',
    title: 'ربات ارسال دایرکت متنی',
    description: 'ارسال پیام مستقیم به کاربران',
    icon: '💌',
    category: 'engagement',
    isActive: true
  },
  {
    id: 'dm-text',
    title: 'ربات ارسال دایرکت اینوه با فروارد',
    description: 'فروارد پست‌ها در دایرکت',
    icon: '📤',
    category: 'engagement',
    isActive: true
  },
  {
    id: 'dm-forward',
    title: 'ربات استخراج فالوورهای پیج هدف',
    description: 'دریافت لیست فالوورها',
    icon: '📋',
    category: 'analytics',
    isActive: true
  },
  {
    id: 'extract-followers',
    title: 'ربات استخراج فالوینگ‌های پیج هدف',
    description: 'دریافت لیست فالوینگ‌ها',
    icon: '📝',
    category: 'analytics',
    isActive: true
  },
  {
    id: 'extract-following',
    title: 'ربات استخراج ای‌دی‌های دایرکت',
    description: 'استخراج اطلاعات دایرکت‌ها',
    icon: '🔍',
    category: 'analytics',
    isActive: true
  },
  {
    id: 'extract-dm-ids',
    title: 'ربات استخراج کامنت گذاران یک پست',
    description: 'دریافت لیست کامنت‌گذاران',
    icon: '💭',
    category: 'analytics',
    isActive: true
  },
  {
    id: 'extract-commenters',
    title: 'ربات استخراج لایک کنندگان یک پست',
    description: 'دریافت لیست لایک‌کنندگان',
    icon: '👍',
    category: 'analytics',
    isActive: true
  },
  {
    id: 'extract-likers',
    title: 'ربات تشخیص فیک و استخراج اطلاعات',
    description: 'تشخیص اکانت‌های فیک',
    icon: '🕵️',
    category: 'analytics',
    isActive: true
  },
  {
    id: 'fake-detection',
    title: 'ربات کامنت و لایک انبوه',
    description: 'لایک و کامنت گروهی',
    icon: '🚀',
    category: 'engagement',
    isActive: true
  },
  {
    id: 'mass-engagement',
    title: 'ربات دانلود از اینستاگرام',
    description: 'دانلود محتوای اینستاگرام',
    icon: '⬇️',
    category: 'content',
    isActive: true
  }
];

export const getServicesByCategory = (category: string) => {
  return botServices.filter(service => service.category === category);
};

export const getAllCategories = () => {
  return [
    { id: 'follower', name: 'مدیریت فالوور', icon: '👥' },
    { id: 'engagement', name: 'تعامل و ارتباط', icon: '💬' },
    { id: 'analytics', name: 'تحلیل و گزارش', icon: '📊' },
    { id: 'content', name: 'محتوا و رسانه', icon: '📱' }
  ];
};