import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Settings, Play, Pause } from 'lucide-react';
import { BotService } from '@/lib/services';

interface ServiceCardProps {
  service: BotService;
  onToggle: (id: string, active: boolean) => void;
  onConfigure: (id: string) => void;
  onStart: (id: string) => void;
}

export default function ServiceCard({ service, onToggle, onConfigure, onStart }: ServiceCardProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'follower': return 'bg-blue-500';
      case 'engagement': return 'bg-green-500';
      case 'analytics': return 'bg-purple-500';
      case 'content': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const getCategoryName = (category: string) => {
    switch (category) {
      case 'follower': return 'فالوور';
      case 'engagement': return 'تعامل';
      case 'analytics': return 'تحلیل';
      case 'content': return 'محتوا';
      default: return 'عمومی';
    }
  };

  return (
    <Card className="h-full transition-all duration-300 hover:shadow-lg hover:scale-105 bg-gradient-to-br from-white to-gray-50 border border-gray-200">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="text-2xl">{service.icon}</div>
            <div>
              <CardTitle className="text-lg font-bold text-gray-800 leading-tight">
                {service.title}
              </CardTitle>
              <Badge 
                variant="secondary" 
                className={`mt-1 text-white ${getCategoryColor(service.category)}`}
              >
                {getCategoryName(service.category)}
              </Badge>
            </div>
          </div>
          <Switch
            checked={service.isActive}
            onCheckedChange={(checked) => onToggle(service.id, checked)}
            className="data-[state=checked]:bg-green-500"
          />
        </div>
      </CardHeader>
      
      <CardContent>
        <CardDescription className="text-gray-600 mb-4 leading-relaxed">
          {service.description}
        </CardDescription>
        
        <div className="flex gap-2">
          <Button
            onClick={() => onStart(service.id)}
            disabled={!service.isActive}
            className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white"
            size="sm"
          >
            {service.isActive ? (
              <>
                <Play className="w-4 h-4 mr-2" />
                شروع
              </>
            ) : (
              <>
                <Pause className="w-4 h-4 mr-2" />
                غیرفعال
              </>
            )}
          </Button>
          
          <Button
            onClick={() => onConfigure(service.id)}
            variant="outline"
            size="sm"
            className="border-gray-300 hover:bg-gray-50"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}