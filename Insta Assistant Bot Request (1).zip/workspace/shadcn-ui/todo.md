# Instagram Bot Assistant - MVP Todo List

## Project Overview
Creating an Instagram bot assistant web application with Persian language support, featuring various automation tools similar to the uploaded images.

## Core Features to Implement
1. **Dashboard Layout** - Main control panel with modern UI
2. **Bot Services Panel** - List of available Instagram automation services
3. **User Authentication** - Simple login/signup interface
4. **Service Cards** - Individual cards for each bot service
5. **Settings Panel** - Configuration options for bot services

## Files to Create/Modify

### 1. src/pages/Index.tsx
- Main dashboard with service cards
- Persian language support
- Modern gradient design

### 2. src/components/ServiceCard.tsx
- Reusable card component for each bot service
- Icons and descriptions
- Action buttons

### 3. src/components/Header.tsx
- Navigation header with logo and user menu
- Language toggle (Persian/English)

### 4. src/components/AuthModal.tsx
- Login/Register modal
- Simple form validation

### 5. src/lib/services.ts
- Data structure for all bot services
- Service categories and descriptions

### 6. src/styles/persian.css
- RTL support for Persian text
- Custom fonts for Persian

### 7. index.html
- Update title to "ربات دستیار اینستاگرام"
- Add Persian meta tags

## Services to Include (Based on Images)
- ربات فالوور کردن (Follower Bot)
- ربات آنفالوور کردن (Unfollower Bot) 
- ربات لایک کردن (Like Bot)
- ربات کامنت گذاشتن (Comment Bot)
- ربات استوری دیدن (Story Viewer Bot)
- ربات دایرکت ارسال (Direct Message Bot)
- ربات تشخیص فیک و استخراج اطلاعات (Fake Detection & Data Extraction)
- And more services from the images

## Design Principles
- Modern gradient backgrounds (pink/purple theme from images)
- Card-based layout
- Persian RTL support
- Responsive design
- Clean and professional UI